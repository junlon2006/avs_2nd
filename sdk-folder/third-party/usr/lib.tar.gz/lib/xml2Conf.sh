#
# Configuration file for using the XML library in GNOME applications
#
XML2_LIBDIR="-L/home/junlon2006/workspace/amazon/avs_2rd/sdk-folder/third-party/usr/lib"
XML2_LIBS="-lxml2 /home/junlon2006/workspace/amazon/avs_2rd/sdk-folder/third-party/usr/lib/libz.a     -lm "
XML2_INCLUDEDIR="-I/home/junlon2006/workspace/amazon/avs_2rd/sdk-folder/third-party/usr/include/libxml2"
MODULE_VERSION="xml2-2.9.8"

